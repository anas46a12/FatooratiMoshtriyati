package com.example.fatooratimoshtriyati

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.MediaStore
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val camera = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) Toast.makeText(this, "تم التقاط الفاتورة. أدخل بياناتها ثم احفظها.", Toast.LENGTH_LONG).show()
    }
    private val permission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) camera.launch(Intent(MediaStore.ACTION_IMAGE_CAPTURE))
        else Toast.makeText(this, "يلزم السماح بالكاميرا لتصوير الفاتورة.", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 40, 32, 24)
            layoutDirection = LinearLayout.LAYOUT_DIRECTION_RTL
        }

        val title = TextView(this).apply {
            text = "فاتورة مشترياتي"
            textSize = 30f
            setPadding(0,0,0,24)
        }
        val intro = TextView(this).apply {
            text = "احفظ فواتيرك وضماناتك في مكان واحد"
            textSize = 17f
            setPadding(0,0,0,24)
        }
        val store = EditText(this).apply { hint = "اسم المتجر"; textSize = 17f }
        val amount = EditText(this).apply { hint = "المبلغ"; inputType = 2 or 8192; textSize = 17f }
        val date = EditText(this).apply { hint = "تاريخ الشراء"; textSize = 17f }
        val warranty = EditText(this).apply { hint = "مدة الضمان (بالأشهر)"; inputType = 2; textSize = 17f }
        val notes = EditText(this).apply { hint = "ملاحظات"; textSize = 17f }

        val capture = Button(this).apply {
            text = "📷 تصوير الفاتورة"
            setOnClickListener {
                if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
                    camera.launch(Intent(MediaStore.ACTION_IMAGE_CAPTURE))
                else permission.launch(Manifest.permission.CAMERA)
            }
        }
        val save = Button(this).apply {
            text = "حفظ الفاتورة"
            setOnClickListener {
                val data = getSharedPreferences("invoices", MODE_PRIVATE)
                val count = data.getInt("count", 0) + 1
                data.edit().putInt("count", count)
                    .putString("invoice_$count", "${store.text} | ${amount.text} | ${date.text} | ضمان: ${warranty.text} شهر | ${notes.text}")
                    .apply()
                Toast.makeText(this@MainActivity, "تم حفظ الفاتورة رقم $count", Toast.LENGTH_SHORT).show()
                store.text.clear(); amount.text.clear(); date.text.clear(); warranty.text.clear(); notes.text.clear()
            }
        }
        val list = Button(this).apply {
            text = "🧾 عرض الفواتير المحفوظة"
            setOnClickListener { showInvoices() }
        }

        layout.addView(title); layout.addView(intro); layout.addView(capture)
        layout.addView(store); layout.addView(amount); layout.addView(date)
        layout.addView(warranty); layout.addView(notes); layout.addView(save); layout.addView(list)
        setContentView(layout)
    }

    private fun showInvoices() {
        val p = getSharedPreferences("invoices", MODE_PRIVATE)
        val count = p.getInt("count", 0)
        val text = if (count == 0) "لا توجد فواتير محفوظة." else buildString {
            for (i in 1..count) append("فاتورة #$i\n${p.getString("invoice_$i","")}\n\n")
        }
        AlertDialog.Builder(this).setTitle("فواتيري").setMessage(text).setPositiveButton("إغلاق", null).show()
    }
}
